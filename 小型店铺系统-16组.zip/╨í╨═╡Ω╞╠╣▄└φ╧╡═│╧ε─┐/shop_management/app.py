"""
小型店铺管理系统 - 主应用入口
功能：进货、售货、商品管理、库存查询、用户管理
技术栈：Flask + SQLite + HTML/CSS/JS
"""

from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, session
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime, timedelta
from functools import wraps
import os
import secrets
import json

# 初始化Flask应用
app = Flask(__name__)
app.config['SECRET_KEY'] = secrets.token_hex(32)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///shop.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['PERMANENT_SESSION_LIFETIME'] = timedelta(days=7)

# 初始化数据库
db = SQLAlchemy(app)

# 初始化登录管理器
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'
login_manager.login_message = '请先登录后再访问此页面'

# ==================== 数据库模型 ====================

class User(UserMixin, db.Model):
    """用户模型"""
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    phone = db.Column(db.String(20))
    role = db.Column(db.String(20), default='staff')  # admin, manager, staff, cashier, warehouse, customer
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_login = db.Column(db.DateTime)
    reset_token = db.Column(db.String(100))
    reset_token_expiry = db.Column(db.DateTime)
    
    # 关系
    sales = db.relationship('Sale', backref='seller', lazy=True)
    purchases = db.relationship('Purchase', backref='operator', lazy=True)
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)
    
    def generate_reset_token(self):
        self.reset_token = secrets.token_urlsafe(32)
        self.reset_token_expiry = datetime.utcnow() + timedelta(hours=24)
        return self.reset_token
    
    @property
    def role_display(self):
        role_names = {
            'admin': '管理员',
            'manager': '经理',
            'staff': '员工',
            'cashier': '收银员',
            'warehouse': '仓库管理员',
            'customer': '客户'
        }
        return role_names.get(self.role, self.role)


class Category(db.Model):
    """商品分类模型"""
    __tablename__ = 'categories'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), unique=True, nullable=False)
    description = db.Column(db.String(200))
    parent_id = db.Column(db.Integer, db.ForeignKey('categories.id'))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # 自引用关系 - 支持多级分类
    children = db.relationship('Category', backref=db.backref('parent', remote_side=[id]))
    products = db.relationship('Product', backref='category', lazy=True)


class Unit(db.Model):
    """商品单位模型"""
    __tablename__ = 'units'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(20), unique=True, nullable=False)
    description = db.Column(db.String(100))
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class MemberLevel(db.Model):
    """会员等级模型"""
    __tablename__ = 'member_levels'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(30), unique=True, nullable=False)
    discount = db.Column(db.Float, default=1.0)  # 折扣率，如0.95表示95折
    points_multiplier = db.Column(db.Float, default=1.0)  # 积分倍率
    min_consumption = db.Column(db.Float, default=0)  # 升级所需最低累计消费
    description = db.Column(db.String(200))
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class PaymentMethod(db.Model):
    """支付方式模型"""
    __tablename__ = 'payment_methods'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(30), unique=True, nullable=False)
    icon = db.Column(db.String(50))  # 图标类名
    description = db.Column(db.String(100))
    is_active = db.Column(db.Boolean, default=True)
    sort_order = db.Column(db.Integer, default=0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class Role(db.Model):
    """用户角色模型"""
    __tablename__ = 'roles'
    
    id = db.Column(db.Integer, primary_key=True)
    code = db.Column(db.String(20), unique=True, nullable=False)
    name = db.Column(db.String(30), nullable=False)
    description = db.Column(db.String(200))
    permissions = db.Column(db.Text)  # JSON格式的权限列表
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class Supplier(db.Model):
    """供应商模型"""
    __tablename__ = 'suppliers'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    contact_person = db.Column(db.String(50))
    phone = db.Column(db.String(20))
    email = db.Column(db.String(120))
    address = db.Column(db.String(200))
    bank_account = db.Column(db.String(50))
    tax_number = db.Column(db.String(50))
    notes = db.Column(db.Text)
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # 关系
    products = db.relationship('Product', backref='supplier', lazy=True)
    purchases = db.relationship('Purchase', backref='supplier', lazy=True)


class Product(db.Model):
    """商品模型"""
    __tablename__ = 'products'
    
    id = db.Column(db.Integer, primary_key=True)
    code = db.Column(db.String(50), unique=True, nullable=False)  # 商品编码/条形码
    name = db.Column(db.String(100), nullable=False)
    category_id = db.Column(db.Integer, db.ForeignKey('categories.id'))
    supplier_id = db.Column(db.Integer, db.ForeignKey('suppliers.id'))
    unit = db.Column(db.String(20), default='个')  # 单位：个、箱、斤、件等
    specification = db.Column(db.String(100))  # 规格
    purchase_price = db.Column(db.Float, default=0)  # 进货价
    selling_price = db.Column(db.Float, default=0)  # 售价
    wholesale_price = db.Column(db.Float, default=0)  # 批发价
    member_price = db.Column(db.Float, default=0)  # 会员价
    stock_quantity = db.Column(db.Integer, default=0)  # 库存数量
    min_stock = db.Column(db.Integer, default=10)  # 最低库存预警
    max_stock = db.Column(db.Integer, default=1000)  # 最高库存
    shelf_location = db.Column(db.String(50))  # 货架位置
    description = db.Column(db.Text)
    image_url = db.Column(db.String(200))
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # 关系
    sale_items = db.relationship('SaleItem', backref='product', lazy=True)
    purchase_items = db.relationship('PurchaseItem', backref='product', lazy=True)
    stock_records = db.relationship('StockRecord', backref='product', lazy=True)
    
    @property
    def profit_margin(self):
        """计算利润率"""
        if self.purchase_price > 0:
            return ((self.selling_price - self.purchase_price) / self.purchase_price) * 100
        return 0


class Customer(db.Model):
    """客户/会员模型"""
    __tablename__ = 'customers'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), nullable=False)
    phone = db.Column(db.String(20), unique=True)
    email = db.Column(db.String(120))
    address = db.Column(db.String(200))
    member_level = db.Column(db.String(20), default='普通')  # 普通、银卡、金卡、钻石
    points = db.Column(db.Integer, default=0)  # 积分
    total_consumption = db.Column(db.Float, default=0)  # 累计消费
    balance = db.Column(db.Float, default=0)  # 账户余额
    birthday = db.Column(db.Date)
    notes = db.Column(db.Text)
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # 关系
    sales = db.relationship('Sale', backref='customer', lazy=True)


class Sale(db.Model):
    """销售订单模型"""
    __tablename__ = 'sales'
    
    id = db.Column(db.Integer, primary_key=True)
    order_no = db.Column(db.String(50), unique=True, nullable=False)  # 订单号
    customer_id = db.Column(db.Integer, db.ForeignKey('customers.id'))
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    total_amount = db.Column(db.Float, default=0)  # 总金额
    discount_amount = db.Column(db.Float, default=0)  # 折扣金额
    actual_amount = db.Column(db.Float, default=0)  # 实付金额
    payment_method = db.Column(db.String(20), default='现金')  # 现金、微信、支付宝、银行卡
    payment_status = db.Column(db.String(20), default='已支付')  # 待支付、已支付、已退款
    order_status = db.Column(db.String(20), default='已完成')  # 待处理、已完成、已取消、已退货
    points_used = db.Column(db.Integer, default=0)  # 使用积分
    points_earned = db.Column(db.Integer, default=0)  # 获得积分
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # 关系
    items = db.relationship('SaleItem', backref='sale', lazy=True, cascade='all, delete-orphan')
    
    @staticmethod
    def generate_order_no():
        """生成订单号"""
        return f"SO{datetime.now().strftime('%Y%m%d%H%M%S')}{secrets.token_hex(3).upper()}"


class SaleItem(db.Model):
    """销售订单明细模型"""
    __tablename__ = 'sale_items'
    
    id = db.Column(db.Integer, primary_key=True)
    sale_id = db.Column(db.Integer, db.ForeignKey('sales.id'), nullable=False)
    product_id = db.Column(db.Integer, db.ForeignKey('products.id'), nullable=False)
    quantity = db.Column(db.Integer, nullable=False)
    unit_price = db.Column(db.Float, nullable=False)  # 单价
    discount = db.Column(db.Float, default=0)  # 折扣
    subtotal = db.Column(db.Float, nullable=False)  # 小计


class Purchase(db.Model):
    """进货订单模型"""
    __tablename__ = 'purchases'
    
    id = db.Column(db.Integer, primary_key=True)
    order_no = db.Column(db.String(50), unique=True, nullable=False)  # 进货单号
    supplier_id = db.Column(db.Integer, db.ForeignKey('suppliers.id'))
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    total_amount = db.Column(db.Float, default=0)  # 总金额
    paid_amount = db.Column(db.Float, default=0)  # 已付金额
    payment_status = db.Column(db.String(20), default='待支付')  # 待支付、部分支付、已支付
    order_status = db.Column(db.String(20), default='待入库')  # 待入库、已入库、已取消
    notes = db.Column(db.Text)
    expected_date = db.Column(db.Date)  # 预计到货日期
    actual_date = db.Column(db.Date)  # 实际到货日期
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # 关系
    items = db.relationship('PurchaseItem', backref='purchase', lazy=True, cascade='all, delete-orphan')
    
    @staticmethod
    def generate_order_no():
        """生成进货单号"""
        return f"PO{datetime.now().strftime('%Y%m%d%H%M%S')}{secrets.token_hex(3).upper()}"


class PurchaseItem(db.Model):
    """进货订单明细模型"""
    __tablename__ = 'purchase_items'
    
    id = db.Column(db.Integer, primary_key=True)
    purchase_id = db.Column(db.Integer, db.ForeignKey('purchases.id'), nullable=False)
    product_id = db.Column(db.Integer, db.ForeignKey('products.id'), nullable=False)
    quantity = db.Column(db.Integer, nullable=False)  # 进货数量
    received_quantity = db.Column(db.Integer, default=0)  # 实收数量
    unit_price = db.Column(db.Float, nullable=False)  # 进货单价
    subtotal = db.Column(db.Float, nullable=False)  # 小计


class StockRecord(db.Model):
    """库存变动记录模型"""
    __tablename__ = 'stock_records'
    
    id = db.Column(db.Integer, primary_key=True)
    product_id = db.Column(db.Integer, db.ForeignKey('products.id'), nullable=False)
    change_type = db.Column(db.String(20), nullable=False)  # 入库、出库、盘点、退货、损耗
    change_quantity = db.Column(db.Integer, nullable=False)  # 变动数量（正数入库，负数出库）
    before_quantity = db.Column(db.Integer, nullable=False)  # 变动前数量
    after_quantity = db.Column(db.Integer, nullable=False)  # 变动后数量
    reference_type = db.Column(db.String(20))  # 关联类型：sale, purchase, inventory
    reference_id = db.Column(db.Integer)  # 关联ID
    notes = db.Column(db.String(200))
    operator_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    operator = db.relationship('User', backref='stock_records')


class InventoryCheck(db.Model):
    """盘点记录模型"""
    __tablename__ = 'inventory_checks'
    
    id = db.Column(db.Integer, primary_key=True)
    check_no = db.Column(db.String(50), unique=True, nullable=False)
    status = db.Column(db.String(20), default='进行中')  # 进行中、已完成、已取消
    total_products = db.Column(db.Integer, default=0)
    checked_products = db.Column(db.Integer, default=0)
    difference_count = db.Column(db.Integer, default=0)  # 差异数量
    notes = db.Column(db.Text)
    operator_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    completed_at = db.Column(db.DateTime)
    
    operator = db.relationship('User', backref='inventory_checks')
    items = db.relationship('InventoryCheckItem', backref='check', lazy=True, cascade='all, delete-orphan')
    
    @staticmethod
    def generate_check_no():
        return f"IC{datetime.now().strftime('%Y%m%d%H%M%S')}{secrets.token_hex(2).upper()}"


class InventoryCheckItem(db.Model):
    """盘点明细模型"""
    __tablename__ = 'inventory_check_items'
    
    id = db.Column(db.Integer, primary_key=True)
    check_id = db.Column(db.Integer, db.ForeignKey('inventory_checks.id'), nullable=False)
    product_id = db.Column(db.Integer, db.ForeignKey('products.id'), nullable=False)
    system_quantity = db.Column(db.Integer, nullable=False)  # 系统数量
    actual_quantity = db.Column(db.Integer)  # 实际数量
    difference = db.Column(db.Integer, default=0)  # 差异
    notes = db.Column(db.String(200))
    
    product = db.relationship('Product')


class SystemLog(db.Model):
    """系统日志模型"""
    __tablename__ = 'system_logs'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    action = db.Column(db.String(50), nullable=False)
    module = db.Column(db.String(50))
    details = db.Column(db.Text)
    ip_address = db.Column(db.String(50))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    user = db.relationship('User', backref='logs')


class SystemSetting(db.Model):
    """系统设置模型"""
    __tablename__ = 'system_settings'
    
    id = db.Column(db.Integer, primary_key=True)
    key = db.Column(db.String(50), unique=True, nullable=False)
    value = db.Column(db.Text)
    description = db.Column(db.String(200))
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


# ==================== 用户加载器 ====================

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))


# ==================== 权限装饰器 ====================

def admin_required(f):
    """管理员权限装饰器"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated or current_user.role != 'admin':
            flash('您没有权限访问此页面', 'error')
            return redirect(url_for('dashboard'))
        return f(*args, **kwargs)
    return decorated_function


def manager_required(f):
    """管理员或经理权限装饰器"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated or current_user.role not in ['admin', 'manager']:
            flash('您没有权限访问此页面', 'error')
            return redirect(url_for('dashboard'))
        return f(*args, **kwargs)
    return decorated_function


def cashier_required(f):
    """收银员及以上权限装饰器"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated or current_user.role not in ['admin', 'manager', 'staff', 'cashier']:
            flash('您没有权限访问此页面', 'error')
            return redirect(url_for('dashboard'))
        return f(*args, **kwargs)
    return decorated_function


# ==================== 辅助函数 ====================

def log_action(action, module=None, details=None):
    """记录操作日志"""
    log = SystemLog(
        user_id=current_user.id if current_user.is_authenticated else None,
        action=action,
        module=module,
        details=details,
        ip_address=request.remote_addr
    )
    db.session.add(log)
    db.session.commit()


def get_setting(key, default=None):
    """获取系统设置"""
    setting = SystemSetting.query.filter_by(key=key).first()
    return setting.value if setting else default


def set_setting(key, value, description=None):
    """设置系统设置"""
    setting = SystemSetting.query.filter_by(key=key).first()
    if setting:
        setting.value = value
    else:
        setting = SystemSetting(key=key, value=value, description=description)
        db.session.add(setting)
    db.session.commit()


def get_all_roles():
    """获取所有可用角色"""
    roles = Role.query.filter_by(is_active=True).all()
    if not roles:
        # 返回默认角色
        return [
            {'code': 'admin', 'name': '管理员'},
            {'code': 'manager', 'name': '经理'},
            {'code': 'staff', 'name': '员工'},
            {'code': 'cashier', 'name': '收银员'},
            {'code': 'warehouse', 'name': '仓库管理员'},
            {'code': 'customer', 'name': '客户'}
        ]
    return [{'code': r.code, 'name': r.name} for r in roles]


# ==================== 认证路由 ====================

@app.route('/')
def index():
    """首页"""
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    return redirect(url_for('login'))


@app.route('/login', methods=['GET', 'POST'])
def login():
    """登录"""
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        remember = request.form.get('remember') == 'on'
        
        user = User.query.filter(
            (User.username == username) | (User.email == username)
        ).first()
        
        if user and user.check_password(password):
            if not user.is_active:
                flash('账号已被禁用，请联系管理员', 'error')
                return render_template('auth/login.html')
            
            login_user(user, remember=remember)
            user.last_login = datetime.utcnow()
            db.session.commit()
            log_action('登录', '认证', f'用户 {username} 登录成功')
            
            next_page = request.args.get('next')
            return redirect(next_page or url_for('dashboard'))
        else:
            flash('用户名或密码错误', 'error')
            log_action('登录失败', '认证', f'用户 {username} 登录失败')
    
    return render_template('auth/login.html')


@app.route('/register', methods=['GET', 'POST'])
def register():
    """注册"""
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        phone = request.form.get('phone')
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')
        
        # 验证
        if password != confirm_password:
            flash('两次输入的密码不一致', 'error')
            return render_template('auth/register.html')
        
        if len(password) < 6:
            flash('密码长度不能少于6位', 'error')
            return render_template('auth/register.html')
        
        if User.query.filter_by(username=username).first():
            flash('用户名已存在', 'error')
            return render_template('auth/register.html')
        
        if User.query.filter_by(email=email).first():
            flash('邮箱已被注册', 'error')
            return render_template('auth/register.html')
        
        # 创建用户
        user = User(username=username, email=email, phone=phone)
        user.set_password(password)
        
        # 第一个用户设为管理员
        if User.query.count() == 0:
            user.role = 'admin'
        
        db.session.add(user)
        db.session.commit()
        
        log_action('注册', '认证', f'新用户 {username} 注册成功')
        flash('注册成功，请登录', 'success')
        return redirect(url_for('login'))
    
    return render_template('auth/register.html')


@app.route('/forgot-password', methods=['GET', 'POST'])
def forgot_password():
    """忘记密码"""
    if request.method == 'POST':
        email = request.form.get('email')
        user = User.query.filter_by(email=email).first()
        
        if user:
            token = user.generate_reset_token()
            db.session.commit()
            # 实际项目中应该发送邮件
            flash(f'密码重置链接已生成。您的重置令牌是：{token}（有效期24小时）', 'info')
            log_action('忘记密码', '认证', f'用户 {email} 请求重置密码')
        else:
            flash('该邮箱未注册', 'error')
        
        return redirect(url_for('reset_password'))
    
    return render_template('auth/forgot_password.html')


@app.route('/reset-password', methods=['GET', 'POST'])
def reset_password():
    """重置密码"""
    if request.method == 'POST':
        token = request.form.get('token')
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')
        
        if password != confirm_password:
            flash('两次输入的密码不一致', 'error')
            return render_template('auth/reset_password.html')
        
        if len(password) < 6:
            flash('密码长度不能少于6位', 'error')
            return render_template('auth/reset_password.html')
        
        user = User.query.filter_by(reset_token=token).first()
        
        if user and user.reset_token_expiry and user.reset_token_expiry > datetime.utcnow():
            user.set_password(password)
            user.reset_token = None
            user.reset_token_expiry = None
            db.session.commit()
            
            log_action('重置密码', '认证', f'用户 {user.username} 重置密码成功')
            flash('密码重置成功，请登录', 'success')
            return redirect(url_for('login'))
        else:
            flash('无效或过期的重置令牌', 'error')
    
    return render_template('auth/reset_password.html')


@app.route('/logout')
@login_required
def logout():
    """退出登录"""
    log_action('退出', '认证', f'用户 {current_user.username} 退出登录')
    logout_user()
    flash('已成功退出登录', 'success')
    return redirect(url_for('login'))


# ==================== 仪表盘路由 ====================

@app.route('/dashboard')
@login_required
def dashboard():
    """仪表盘"""
    # 今日统计
    today = datetime.utcnow().date()
    today_start = datetime.combine(today, datetime.min.time())
    today_end = datetime.combine(today, datetime.max.time())
    
    # 今日销售额
    today_sales = db.session.query(db.func.sum(Sale.actual_amount)).filter(
        Sale.created_at.between(today_start, today_end),
        Sale.order_status == '已完成'
    ).scalar() or 0
    
    # 今日订单数
    today_orders = Sale.query.filter(
        Sale.created_at.between(today_start, today_end)
    ).count()
    
    # 库存预警商品数
    low_stock_count = Product.query.filter(
        Product.stock_quantity <= Product.min_stock,
        Product.is_active == True
    ).count()
    
    # 商品总数
    total_products = Product.query.filter_by(is_active=True).count()
    
    # 本月销售趋势
    month_start = today.replace(day=1)
    sales_trend_raw = db.session.query(
        db.func.date(Sale.created_at).label('date'),
        db.func.sum(Sale.actual_amount).label('amount')
    ).filter(
        Sale.created_at >= month_start,
        Sale.order_status == '已完成'
    ).group_by(db.func.date(Sale.created_at)).all()
    
    sales_trend = []
    for row in sales_trend_raw:
        date_str = str(row[0]) if row[0] else ''
        amount = float(row[1]) if row[1] else 0
        sales_trend.append([date_str, amount])
    
    # 最近销售订单
    recent_sales = Sale.query.order_by(Sale.created_at.desc()).limit(10).all()
    
    # 热销商品
    hot_products = db.session.query(
        Product,
        db.func.sum(SaleItem.quantity).label('sold_quantity')
    ).join(SaleItem).join(Sale).filter(
        Sale.created_at >= month_start,
        Sale.order_status == '已完成'
    ).group_by(Product.id).order_by(db.func.sum(SaleItem.quantity).desc()).limit(5).all()
    
    # 库存预警商品
    low_stock_products = Product.query.filter(
        Product.stock_quantity <= Product.min_stock,
        Product.is_active == True
    ).limit(5).all()
    
    return render_template('dashboard.html',
        today_sales=today_sales,
        today_orders=today_orders,
        low_stock_count=low_stock_count,
        total_products=total_products,
        sales_trend=sales_trend,
        recent_sales=recent_sales,
        hot_products=hot_products,
        low_stock_products=low_stock_products
    )


# ==================== 商品管理路由 ====================

@app.route('/products')
@login_required
def products():
    """商品列表"""
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 20, type=int)
    search = request.args.get('search', '')
    category_id = request.args.get('category_id', type=int)
    stock_status = request.args.get('stock_status', '')
    
    query = Product.query.filter_by(is_active=True)
    
    if search:
        query = query.filter(
            (Product.name.contains(search)) | 
            (Product.code.contains(search))
        )
    
    if category_id:
        query = query.filter_by(category_id=category_id)
    
    if stock_status == 'low':
        query = query.filter(Product.stock_quantity <= Product.min_stock)
    elif stock_status == 'out':
        query = query.filter(Product.stock_quantity == 0)
    elif stock_status == 'normal':
        query = query.filter(Product.stock_quantity > Product.min_stock)
    
    pagination = query.order_by(Product.updated_at.desc()).paginate(
        page=page, per_page=per_page, error_out=False
    )
    
    categories = Category.query.all()
    
    return render_template('products/list.html',
        products=pagination.items,
        pagination=pagination,
        categories=categories,
        search=search,
        category_id=category_id,
        stock_status=stock_status
    )


@app.route('/products/add', methods=['GET', 'POST'])
@login_required
def add_product():
    """添加商品"""
    if request.method == 'POST':
        code = request.form.get('code')
        name = request.form.get('name')
        category_id = request.form.get('category_id', type=int)
        supplier_id = request.form.get('supplier_id', type=int)
        unit = request.form.get('unit', '个')
        specification = request.form.get('specification')
        purchase_price = request.form.get('purchase_price', 0, type=float)
        selling_price = request.form.get('selling_price', 0, type=float)
        wholesale_price = request.form.get('wholesale_price', 0, type=float)
        member_price = request.form.get('member_price', 0, type=float)
        stock_quantity = request.form.get('stock_quantity', 0, type=int)
        min_stock = request.form.get('min_stock', 10, type=int)
        max_stock = request.form.get('max_stock', 1000, type=int)
        shelf_location = request.form.get('shelf_location')
        description = request.form.get('description')
        
        # 检查商品编码是否存在
        if Product.query.filter_by(code=code).first():
            flash('商品编码已存在', 'error')
            categories = Category.query.all()
            suppliers = Supplier.query.filter_by(is_active=True).all()
            units = Unit.query.filter_by(is_active=True).all()
            return render_template('products/form.html', categories=categories, suppliers=suppliers, units=units)
        
        product = Product(
            code=code,
            name=name,
            category_id=category_id if category_id else None,
            supplier_id=supplier_id if supplier_id else None,
            unit=unit,
            specification=specification,
            purchase_price=purchase_price,
            selling_price=selling_price,
            wholesale_price=wholesale_price,
            member_price=member_price,
            stock_quantity=stock_quantity,
            min_stock=min_stock,
            max_stock=max_stock,
            shelf_location=shelf_location,
            description=description
        )
        
        db.session.add(product)
        db.session.commit()
        
        # 记录初始库存
        if stock_quantity > 0:
            stock_record = StockRecord(
                product_id=product.id,
                change_type='入库',
                change_quantity=stock_quantity,
                before_quantity=0,
                after_quantity=stock_quantity,
                reference_type='init',
                notes='初始库存',
                operator_id=current_user.id
            )
            db.session.add(stock_record)
            db.session.commit()
        
        log_action('添加商品', '商品管理', f'添加商品：{name}')
        flash('商品添加成功', 'success')
        return redirect(url_for('products'))
    
    categories = Category.query.all()
    suppliers = Supplier.query.filter_by(is_active=True).all()
    units = Unit.query.filter_by(is_active=True).all()
    return render_template('products/form.html', categories=categories, suppliers=suppliers, units=units)


@app.route('/products/edit/<int:id>', methods=['GET', 'POST'])
@login_required
def edit_product(id):
    """编辑商品"""
    product = Product.query.get_or_404(id)
    
    if request.method == 'POST':
        product.code = request.form.get('code')
        product.name = request.form.get('name')
        product.category_id = request.form.get('category_id', type=int) or None
        product.supplier_id = request.form.get('supplier_id', type=int) or None
        product.unit = request.form.get('unit', '个')
        product.specification = request.form.get('specification')
        product.purchase_price = request.form.get('purchase_price', 0, type=float)
        product.selling_price = request.form.get('selling_price', 0, type=float)
        product.wholesale_price = request.form.get('wholesale_price', 0, type=float)
        product.member_price = request.form.get('member_price', 0, type=float)
        product.min_stock = request.form.get('min_stock', 10, type=int)
        product.max_stock = request.form.get('max_stock', 1000, type=int)
        product.shelf_location = request.form.get('shelf_location')
        product.description = request.form.get('description')
        
        db.session.commit()
        
        log_action('编辑商品', '商品管理', f'编辑商品：{product.name}')
        flash('商品更新成功', 'success')
        return redirect(url_for('products'))
    
    categories = Category.query.all()
    suppliers = Supplier.query.filter_by(is_active=True).all()
    units = Unit.query.filter_by(is_active=True).all()
    return render_template('products/form.html', product=product, categories=categories, suppliers=suppliers, units=units)


@app.route('/products/view/<int:id>')
@login_required
def view_product(id):
    """查看商品详情"""
    product = Product.query.get_or_404(id)
    
    # 获取最近的库存变动记录
    stock_records = StockRecord.query.filter_by(product_id=id).order_by(
        StockRecord.created_at.desc()
    ).limit(10).all()
    
    # 获取销售统计
    month_start = datetime.utcnow().date().replace(day=1)
    monthly_sales = db.session.query(db.func.sum(SaleItem.quantity)).join(Sale).filter(
        SaleItem.product_id == id,
        Sale.created_at >= month_start,
        Sale.order_status == '已完成'
    ).scalar() or 0
    
    return render_template('products/view.html',
        product=product,
        stock_records=stock_records,
        monthly_sales=monthly_sales
    )


@app.route('/products/delete/<int:id>', methods=['POST'])
@login_required
@manager_required
def delete_product(id):
    """删除商品（软删除）"""
    product = Product.query.get_or_404(id)
    product.is_active = False
    db.session.commit()
    
    log_action('删除商品', '商品管理', f'删除商品：{product.name}')
    flash('商品已删除', 'success')
    return redirect(url_for('products'))


# ==================== 分类管理路由 ====================

@app.route('/categories')
@login_required
def categories():
    """分类列表"""
    categories = Category.query.all()
    return render_template('categories/list.html', categories=categories)


@app.route('/categories/add', methods=['GET', 'POST'])
@login_required
def add_category():
    """添加分类"""
    if request.method == 'POST':
        name = request.form.get('name')
        parent_id = request.form.get('parent_id', type=int)
        description = request.form.get('description')
        
        if Category.query.filter_by(name=name).first():
            flash('分类名称已存在', 'error')
            categories = Category.query.all()
            return render_template('categories/form.html', categories=categories)
        
        category = Category(
            name=name,
            parent_id=parent_id if parent_id else None,
            description=description
        )
        db.session.add(category)
        db.session.commit()
        
        log_action('添加分类', '分类管理', f'添加分类：{name}')
        flash('分类添加成功', 'success')
        return redirect(url_for('categories'))
    
    categories = Category.query.all()
    return render_template('categories/form.html', categories=categories)


@app.route('/categories/edit/<int:id>', methods=['GET', 'POST'])
@login_required
def edit_category(id):
    """编辑分类"""
    category = Category.query.get_or_404(id)
    
    if request.method == 'POST':
        category.name = request.form.get('name')
        category.parent_id = request.form.get('parent_id', type=int) or None
        category.description = request.form.get('description')
        
        db.session.commit()
        
        log_action('编辑分类', '分类管理', f'编辑分类：{category.name}')
        flash('分类更新成功', 'success')
        return redirect(url_for('categories'))
    
    categories = Category.query.filter(Category.id != id).all()
    return render_template('categories/form.html', category=category, categories=categories)


@app.route('/categories/delete/<int:id>', methods=['POST'])
@login_required
@manager_required
def delete_category(id):
    """删除分类"""
    category = Category.query.get_or_404(id)
    
    if category.products or category.children:
        flash('该分类下有商品或子分类，无法删除', 'error')
        return redirect(url_for('categories'))
    
    db.session.delete(category)
    db.session.commit()
    
    log_action('删除分类', '分类管理', f'删除分类：{category.name}')
    flash('分类已删除', 'success')
    return redirect(url_for('categories'))


# ==================== 商品单位管理路由 ====================

@app.route('/units')
@login_required
def units():
    """单位列表"""
    units = Unit.query.filter_by(is_active=True).all()
    return render_template('units/list.html', units=units)


@app.route('/units/add', methods=['GET', 'POST'])
@login_required
@manager_required
def add_unit():
    """添加单位"""
    if request.method == 'POST':
        name = request.form.get('name')
        description = request.form.get('description')
        
        if Unit.query.filter_by(name=name).first():
            flash('单位名称已存在', 'error')
            return render_template('units/form.html')
        
        unit = Unit(name=name, description=description)
        db.session.add(unit)
        db.session.commit()
        
        log_action('添加单位', '单位管理', f'添加单位：{name}')
        flash('单位添加成功', 'success')
        return redirect(url_for('units'))
    
    return render_template('units/form.html')


@app.route('/units/edit/<int:id>', methods=['GET', 'POST'])
@login_required
@manager_required
def edit_unit(id):
    """编辑单位"""
    unit = Unit.query.get_or_404(id)
    
    if request.method == 'POST':
        unit.name = request.form.get('name')
        unit.description = request.form.get('description')
        
        db.session.commit()
        
        log_action('编辑单位', '单位管理', f'编辑单位：{unit.name}')
        flash('单位更新成功', 'success')
        return redirect(url_for('units'))
    
    return render_template('units/form.html', unit=unit)


@app.route('/units/delete/<int:id>', methods=['POST'])
@login_required
@admin_required
def delete_unit(id):
    """删除单位"""
    unit = Unit.query.get_or_404(id)
    unit.is_active = False
    db.session.commit()
    
    log_action('删除单位', '单位管理', f'删除单位：{unit.name}')
    flash('单位已删除', 'success')
    return redirect(url_for('units'))


# ==================== 会员等级管理路由 ====================

@app.route('/member-levels')
@login_required
@manager_required
def member_levels():
    """会员等级列表"""
    levels = MemberLevel.query.filter_by(is_active=True).order_by(MemberLevel.min_consumption).all()
    return render_template('member_levels/list.html', levels=levels)


@app.route('/member-levels/add', methods=['GET', 'POST'])
@login_required
@admin_required
def add_member_level():
    """添加会员等级"""
    if request.method == 'POST':
        name = request.form.get('name')
        discount = request.form.get('discount', 1.0, type=float)
        points_multiplier = request.form.get('points_multiplier', 1.0, type=float)
        min_consumption = request.form.get('min_consumption', 0, type=float)
        description = request.form.get('description')
        
        if MemberLevel.query.filter_by(name=name).first():
            flash('会员等级名称已存在', 'error')
            return render_template('member_levels/form.html')
        
        level = MemberLevel(
            name=name,
            discount=discount,
            points_multiplier=points_multiplier,
            min_consumption=min_consumption,
            description=description
        )
        db.session.add(level)
        db.session.commit()
        
        log_action('添加会员等级', '会员管理', f'添加会员等级：{name}')
        flash('会员等级添加成功', 'success')
        return redirect(url_for('member_levels'))
    
    return render_template('member_levels/form.html')


@app.route('/member-levels/edit/<int:id>', methods=['GET', 'POST'])
@login_required
@admin_required
def edit_member_level(id):
    """编辑会员等级"""
    level = MemberLevel.query.get_or_404(id)
    
    if request.method == 'POST':
        level.name = request.form.get('name')
        level.discount = request.form.get('discount', 1.0, type=float)
        level.points_multiplier = request.form.get('points_multiplier', 1.0, type=float)
        level.min_consumption = request.form.get('min_consumption', 0, type=float)
        level.description = request.form.get('description')
        
        db.session.commit()
        
        log_action('编辑会员等级', '会员管理', f'编辑会员等级：{level.name}')
        flash('会员等级更新成功', 'success')
        return redirect(url_for('member_levels'))
    
    return render_template('member_levels/form.html', level=level)


@app.route('/member-levels/delete/<int:id>', methods=['POST'])
@login_required
@admin_required
def delete_member_level(id):
    """删除会员等级"""
    level = MemberLevel.query.get_or_404(id)
    level.is_active = False
    db.session.commit()
    
    log_action('删除会员等级', '会员管理', f'删除会员等级：{level.name}')
    flash('会员等级已删除', 'success')
    return redirect(url_for('member_levels'))


# ==================== 支付方式管理路由 ====================

@app.route('/payment-methods')
@login_required
@manager_required
def payment_methods():
    """支付方式列表"""
    methods = PaymentMethod.query.filter_by(is_active=True).order_by(PaymentMethod.sort_order).all()
    return render_template('payment_methods/list.html', methods=methods)


@app.route('/payment-methods/add', methods=['GET', 'POST'])
@login_required
@admin_required
def add_payment_method():
    """添加支付方式"""
    if request.method == 'POST':
        name = request.form.get('name')
        icon = request.form.get('icon')
        description = request.form.get('description')
        sort_order = request.form.get('sort_order', 0, type=int)
        
        if PaymentMethod.query.filter_by(name=name).first():
            flash('支付方式名称已存在', 'error')
            return render_template('payment_methods/form.html')
        
        method = PaymentMethod(
            name=name,
            icon=icon,
            description=description,
            sort_order=sort_order
        )
        db.session.add(method)
        db.session.commit()
        
        log_action('添加支付方式', '系统设置', f'添加支付方式：{name}')
        flash('支付方式添加成功', 'success')
        return redirect(url_for('payment_methods'))
    
    return render_template('payment_methods/form.html')


@app.route('/payment-methods/edit/<int:id>', methods=['GET', 'POST'])
@login_required
@admin_required
def edit_payment_method(id):
    """编辑支付方式"""
    method = PaymentMethod.query.get_or_404(id)
    
    if request.method == 'POST':
        method.name = request.form.get('name')
        method.icon = request.form.get('icon')
        method.description = request.form.get('description')
        method.sort_order = request.form.get('sort_order', 0, type=int)
        
        db.session.commit()
        
        log_action('编辑支付方式', '系统设置', f'编辑支付方式：{method.name}')
        flash('支付方式更新成功', 'success')
        return redirect(url_for('payment_methods'))
    
    return render_template('payment_methods/form.html', method=method)


@app.route('/payment-methods/delete/<int:id>', methods=['POST'])
@login_required
@admin_required
def delete_payment_method(id):
    """删除支付方式"""
    method = PaymentMethod.query.get_or_404(id)
    method.is_active = False
    db.session.commit()
    
    log_action('删除支付方式', '系统设置', f'删除支付方式：{method.name}')
    flash('支付方式已删除', 'success')
    return redirect(url_for('payment_methods'))


# ==================== 用户角色管理路由 ====================

@app.route('/roles')
@login_required
@admin_required
def roles():
    """角色列表"""
    roles = Role.query.filter_by(is_active=True).all()
    return render_template('roles/list.html', roles=roles)


@app.route('/roles/add', methods=['GET', 'POST'])
@login_required
@admin_required
def add_role():
    """添加角色"""
    if request.method == 'POST':
        code = request.form.get('code')
        name = request.form.get('name')
        description = request.form.get('description')
        permissions = request.form.getlist('permissions')
        
        if Role.query.filter_by(code=code).first():
            flash('角色代码已存在', 'error')
            return render_template('roles/form.html')
        
        role = Role(
            code=code,
            name=name,
            description=description,
            permissions=json.dumps(permissions)
        )
        db.session.add(role)
        db.session.commit()
        
        log_action('添加角色', '角色管理', f'添加角色：{name}')
        flash('角色添加成功', 'success')
        return redirect(url_for('roles'))
    
    return render_template('roles/form.html')


@app.route('/roles/edit/<int:id>', methods=['GET', 'POST'])
@login_required
@admin_required
def edit_role(id):
    """编辑角色"""
    role = Role.query.get_or_404(id)
    
    if request.method == 'POST':
        role.name = request.form.get('name')
        role.description = request.form.get('description')
        permissions = request.form.getlist('permissions')
        role.permissions = json.dumps(permissions)
        
        db.session.commit()
        
        log_action('编辑角色', '角色管理', f'编辑角色：{role.name}')
        flash('角色更新成功', 'success')
        return redirect(url_for('roles'))
    
    return render_template('roles/form.html', role=role)


@app.route('/roles/delete/<int:id>', methods=['POST'])
@login_required
@admin_required
def delete_role(id):
    """删除角色"""
    role = Role.query.get_or_404(id)
    role.is_active = False
    db.session.commit()
    
    log_action('删除角色', '角色管理', f'删除角色：{role.name}')
    flash('角色已删除', 'success')
    return redirect(url_for('roles'))


# ==================== 供应商管理路由 ====================

@app.route('/suppliers')
@login_required
def suppliers():
    """供应商列表"""
    page = request.args.get('page', 1, type=int)
    search = request.args.get('search', '')
    
    query = Supplier.query.filter_by(is_active=True)
    
    if search:
        query = query.filter(
            (Supplier.name.contains(search)) |
            (Supplier.contact_person.contains(search)) |
            (Supplier.phone.contains(search))
        )
    
    pagination = query.order_by(Supplier.created_at.desc()).paginate(
        page=page, per_page=20, error_out=False
    )
    
    return render_template('suppliers/list.html',
        suppliers=pagination.items,
        pagination=pagination,
        search=search
    )


@app.route('/suppliers/add', methods=['GET', 'POST'])
@login_required
def add_supplier():
    """添加供应商"""
    if request.method == 'POST':
        supplier = Supplier(
            name=request.form.get('name'),
            contact_person=request.form.get('contact_person'),
            phone=request.form.get('phone'),
            email=request.form.get('email'),
            address=request.form.get('address'),
            bank_account=request.form.get('bank_account'),
            tax_number=request.form.get('tax_number'),
            notes=request.form.get('notes')
        )
        db.session.add(supplier)
        db.session.commit()
        
        log_action('添加供应商', '供应商管理', f'添加供应商：{supplier.name}')
        flash('供应商添加成功', 'success')
        return redirect(url_for('suppliers'))
    
    return render_template('suppliers/form.html')


@app.route('/suppliers/edit/<int:id>', methods=['GET', 'POST'])
@login_required
def edit_supplier(id):
    """编辑供应商"""
    supplier = Supplier.query.get_or_404(id)
    
    if request.method == 'POST':
        supplier.name = request.form.get('name')
        supplier.contact_person = request.form.get('contact_person')
        supplier.phone = request.form.get('phone')
        supplier.email = request.form.get('email')
        supplier.address = request.form.get('address')
        supplier.bank_account = request.form.get('bank_account')
        supplier.tax_number = request.form.get('tax_number')
        supplier.notes = request.form.get('notes')
        
        db.session.commit()
        
        log_action('编辑供应商', '供应商管理', f'编辑供应商：{supplier.name}')
        flash('供应商更新成功', 'success')
        return redirect(url_for('suppliers'))
    
    return render_template('suppliers/form.html', supplier=supplier)


@app.route('/suppliers/view/<int:id>')
@login_required
def view_supplier(id):
    """查看供应商详情"""
    supplier = Supplier.query.get_or_404(id)
    
    # 获取该供应商的商品
    products = Product.query.filter_by(supplier_id=id, is_active=True).all()
    
    # 获取该供应商的进货记录
    purchases = Purchase.query.filter_by(supplier_id=id).order_by(
        Purchase.created_at.desc()
    ).limit(10).all()
    
    return render_template('suppliers/view.html',
        supplier=supplier,
        products=products,
        purchases=purchases
    )


@app.route('/suppliers/delete/<int:id>', methods=['POST'])
@login_required
@manager_required
def delete_supplier(id):
    """删除供应商"""
    supplier = Supplier.query.get_or_404(id)
    supplier.is_active = False
    db.session.commit()
    
    log_action('删除供应商', '供应商管理', f'删除供应商：{supplier.name}')
    flash('供应商已删除', 'success')
    return redirect(url_for('suppliers'))


# ==================== 进货管理路由 ====================

@app.route('/purchases')
@login_required
def purchases():
    """进货列表"""
    page = request.args.get('page', 1, type=int)
    status = request.args.get('status', '')
    
    query = Purchase.query
    
    if status:
        query = query.filter_by(order_status=status)
    
    pagination = query.order_by(Purchase.created_at.desc()).paginate(
        page=page, per_page=20, error_out=False
    )
    
    return render_template('purchases/list.html',
        purchases=pagination.items,
        pagination=pagination,
        status=status
    )


@app.route('/purchases/add', methods=['GET', 'POST'])
@login_required
def add_purchase():
    """新建进货单"""
    if request.method == 'POST':
        supplier_id = request.form.get('supplier_id', type=int)
        expected_date = request.form.get('expected_date')
        notes = request.form.get('notes')
        
        product_ids = request.form.getlist('product_id[]')
        quantities = request.form.getlist('quantity[]')
        unit_prices = request.form.getlist('unit_price[]')
        
        purchase = Purchase(
            order_no=Purchase.generate_order_no(),
            supplier_id=supplier_id if supplier_id else None,
            user_id=current_user.id,
            expected_date=datetime.strptime(expected_date, '%Y-%m-%d').date() if expected_date else None,
            notes=notes
        )
        db.session.add(purchase)
        
        total_amount = 0
        for i, product_id in enumerate(product_ids):
            if product_id and quantities[i]:
                quantity = int(quantities[i])
                unit_price = float(unit_prices[i]) if unit_prices[i] else 0
                subtotal = quantity * unit_price
                
                item = PurchaseItem(
                    purchase=purchase,
                    product_id=int(product_id),
                    quantity=quantity,
                    unit_price=unit_price,
                    subtotal=subtotal
                )
                db.session.add(item)
                total_amount += subtotal
        
        purchase.total_amount = total_amount
        db.session.commit()
        
        log_action('新建进货单', '进货管理', f'进货单：{purchase.order_no}')
        flash('进货单创建成功', 'success')
        return redirect(url_for('purchases'))
    
    suppliers = Supplier.query.filter_by(is_active=True).all()
    products = Product.query.filter_by(is_active=True).all()
    return render_template('purchases/form.html', suppliers=suppliers, products=products)


@app.route('/purchases/view/<int:id>')
@login_required
def view_purchase(id):
    """查看进货单"""
    purchase = Purchase.query.get_or_404(id)
    return render_template('purchases/view.html', purchase=purchase)


@app.route('/purchases/receive/<int:id>', methods=['GET', 'POST'])
@login_required
def receive_purchase(id):
    """收货入库"""
    purchase = Purchase.query.get_or_404(id)
    
    if purchase.order_status == '已入库':
        flash('该进货单已入库', 'warning')
        return redirect(url_for('view_purchase', id=id))
    
    if request.method == 'POST':
        received_quantities = request.form.getlist('received_quantity[]')
        
        for i, item in enumerate(purchase.items):
            received_qty = int(received_quantities[i]) if received_quantities[i] else 0
            item.received_quantity = received_qty
            
            if received_qty > 0:
                # 更新库存
                product = item.product
                before_quantity = product.stock_quantity
                product.stock_quantity += received_qty
                
                # 记录库存变动
                stock_record = StockRecord(
                    product_id=product.id,
                    change_type='入库',
                    change_quantity=received_qty,
                    before_quantity=before_quantity,
                    after_quantity=product.stock_quantity,
                    reference_type='purchase',
                    reference_id=purchase.id,
                    notes=f'进货单：{purchase.order_no}',
                    operator_id=current_user.id
                )
                db.session.add(stock_record)
        
        purchase.order_status = '已入库'
        purchase.actual_date = datetime.utcnow().date()
        db.session.commit()
        
        log_action('收货入库', '进货管理', f'进货单：{purchase.order_no}')
        flash('收货入库成功', 'success')
        return redirect(url_for('view_purchase', id=id))
    
    return render_template('purchases/receive.html', purchase=purchase)


# ==================== 客户管理路由 ====================

@app.route('/customers')
@login_required
def customers():
    """客户列表"""
    page = request.args.get('page', 1, type=int)
    search = request.args.get('search', '')
    member_level = request.args.get('member_level', '')
    
    query = Customer.query.filter_by(is_active=True)
    
    if search:
        query = query.filter(
            (Customer.name.contains(search)) |
            (Customer.phone.contains(search))
        )
    
    if member_level:
        query = query.filter_by(member_level=member_level)
    
    pagination = query.order_by(Customer.created_at.desc()).paginate(
        page=page, per_page=20, error_out=False
    )
    
    # 获取会员等级列表
    levels = MemberLevel.query.filter_by(is_active=True).all()
    
    return render_template('customers/list.html',
        customers=pagination.items,
        pagination=pagination,
        search=search,
        member_level=member_level,
        levels=levels
    )


@app.route('/customers/add', methods=['GET', 'POST'])
@login_required
def add_customer():
    """添加客户"""
    if request.method == 'POST':
        phone = request.form.get('phone')
        
        if Customer.query.filter_by(phone=phone).first():
            flash('该手机号已注册', 'error')
            levels = MemberLevel.query.filter_by(is_active=True).all()
            return render_template('customers/form.html', levels=levels)
        
        birthday = request.form.get('birthday')
        customer = Customer(
            name=request.form.get('name'),
            phone=phone,
            email=request.form.get('email'),
            address=request.form.get('address'),
            member_level=request.form.get('member_level', '普通'),
            birthday=datetime.strptime(birthday, '%Y-%m-%d').date() if birthday else None,
            notes=request.form.get('notes')
        )
        db.session.add(customer)
        db.session.commit()
        
        log_action('添加客户', '客户管理', f'添加客户：{customer.name}')
        flash('客户添加成功', 'success')
        return redirect(url_for('customers'))
    
    levels = MemberLevel.query.filter_by(is_active=True).all()
    return render_template('customers/form.html', levels=levels)


@app.route('/customers/edit/<int:id>', methods=['GET', 'POST'])
@login_required
def edit_customer(id):
    """编辑客户"""
    customer = Customer.query.get_or_404(id)
    
    if request.method == 'POST':
        customer.name = request.form.get('name')
        customer.phone = request.form.get('phone')
        customer.email = request.form.get('email')
        customer.address = request.form.get('address')
        customer.member_level = request.form.get('member_level', '普通')
        birthday = request.form.get('birthday')
        customer.birthday = datetime.strptime(birthday, '%Y-%m-%d').date() if birthday else None
        customer.notes = request.form.get('notes')
        
        db.session.commit()
        
        log_action('编辑客户', '客户管理', f'编辑客户：{customer.name}')
        flash('客户更新成功', 'success')
        return redirect(url_for('customers'))
    
    levels = MemberLevel.query.filter_by(is_active=True).all()
    return render_template('customers/form.html', customer=customer, levels=levels)


@app.route('/customers/view/<int:id>')
@login_required
def view_customer(id):
    """查看客户详情"""
    customer = Customer.query.get_or_404(id)
    
    # 获取该客户的消费记录
    sales = Sale.query.filter_by(customer_id=id).order_by(
        Sale.created_at.desc()
    ).limit(20).all()
    
    return render_template('customers/view.html', customer=customer, sales=sales)


# ==================== 销售管理路由 ====================

@app.route('/sales')
@login_required
def sales():
    """销售列表"""
    page = request.args.get('page', 1, type=int)
    status = request.args.get('status', '')
    date_from = request.args.get('date_from', '')
    date_to = request.args.get('date_to', '')
    
    query = Sale.query
    
    if status:
        query = query.filter_by(order_status=status)
    
    if date_from:
        query = query.filter(Sale.created_at >= datetime.strptime(date_from, '%Y-%m-%d'))
    
    if date_to:
        query = query.filter(Sale.created_at <= datetime.strptime(date_to, '%Y-%m-%d') + timedelta(days=1))
    
    pagination = query.order_by(Sale.created_at.desc()).paginate(
        page=page, per_page=20, error_out=False
    )
    
    return render_template('sales/list.html',
        sales=pagination.items,
        pagination=pagination,
        status=status,
        date_from=date_from,
        date_to=date_to
    )


@app.route('/sales/pos')
@login_required
def pos():
    """收银台"""
    products = Product.query.filter_by(is_active=True).all()
    categories = Category.query.all()
    customers = Customer.query.filter_by(is_active=True).all()
    payment_methods_list = PaymentMethod.query.filter_by(is_active=True).order_by(PaymentMethod.sort_order).all()
    
    return render_template('sales/pos.html',
        products=products,
        categories=categories,
        customers=customers,
        payment_methods=payment_methods_list
    )


@app.route('/sales/checkout', methods=['POST'])
@login_required
def checkout():
    """结算"""
    try:
        data = request.get_json()
        
        customer_id = data.get('customer_id')
        payment_method = data.get('payment_method', '现金')
        discount_amount = data.get('discount_amount', 0)
        points_used = data.get('points_used', 0)
        notes = data.get('notes', '')
        items = data.get('items', [])
        
        if not items:
            return jsonify({'success': False, 'message': '购物车为空'})
        
        # 创建销售订单
        sale = Sale(
            order_no=Sale.generate_order_no(),
            customer_id=customer_id if customer_id else None,
            user_id=current_user.id,
            payment_method=payment_method,
            discount_amount=float(discount_amount),
            points_used=int(points_used),
            notes=notes
        )
        
        db.session.add(sale)
        
        # 添加明细并更新库存
        total_amount = 0
        for item in items:
            product = Product.query.get(item['product_id'])
            if not product:
                db.session.rollback()
                return jsonify({'success': False, 'message': f'商品不存在'})
            
            quantity = int(item['quantity'])
            if product.stock_quantity < quantity:
                db.session.rollback()
                return jsonify({'success': False, 'message': f'{product.name} 库存不足'})
            
            unit_price = float(item.get('unit_price', product.selling_price))
            discount = float(item.get('discount', 0))
            subtotal = quantity * unit_price - discount
            
            sale_item = SaleItem(
                sale=sale,
                product_id=product.id,
                quantity=quantity,
                unit_price=unit_price,
                discount=discount,
                subtotal=subtotal
            )
            db.session.add(sale_item)
            
            # 更新库存
            before_quantity = product.stock_quantity
            product.stock_quantity -= quantity
            
            # 记录库存变动
            stock_record = StockRecord(
                product_id=product.id,
                change_type='出库',
                change_quantity=-quantity,
                before_quantity=before_quantity,
                after_quantity=product.stock_quantity,
                reference_type='sale',
                reference_id=sale.id,
                notes=f'销售单：{sale.order_no}',
                operator_id=current_user.id
            )
            db.session.add(stock_record)
            
            total_amount += subtotal
        
        sale.total_amount = total_amount
        sale.actual_amount = total_amount - sale.discount_amount - (points_used * 0.01)  # 积分抵扣
        
        # 处理会员积分
        if customer_id:
            customer = Customer.query.get(customer_id)
            if customer:
                # 扣除使用的积分
                if points_used > 0:
                    customer.points -= points_used
                
                # 增加消费记录和新积分
                customer.total_consumption += sale.actual_amount
                earned_points = int(sale.actual_amount)  # 1元=1积分
                customer.points += earned_points
                sale.points_earned = earned_points
        
        db.session.commit()
        
        log_action('销售结算', '销售管理', f'销售单：{sale.order_no}，金额：{sale.actual_amount}')
        
        return jsonify({
            'success': True,
            'message': '结算成功',
            'order_no': sale.order_no,
            'actual_amount': sale.actual_amount
        })
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': f'结算出错：{str(e)}'})


@app.route('/sales/view/<int:id>')
@login_required
def view_sale(id):
    """查看销售订单"""
    sale = Sale.query.get_or_404(id)
    return render_template('sales/view.html', sale=sale)


@app.route('/sales/refund/<int:id>', methods=['GET', 'POST'])
@login_required
@manager_required
def refund_sale(id):
    """退货退款"""
    sale = Sale.query.get_or_404(id)
    
    if sale.order_status == '已退货':
        flash('该订单已退货', 'warning')
        return redirect(url_for('view_sale', id=id))
    
    if request.method == 'POST':
        refund_items = request.form.getlist('refund_quantity[]')
        
        for i, item in enumerate(sale.items):
            refund_qty = int(refund_items[i]) if refund_items[i] else 0
            
            if refund_qty > 0 and refund_qty <= item.quantity:
                # 恢复库存
                product = item.product
                before_quantity = product.stock_quantity
                product.stock_quantity += refund_qty
                
                # 记录库存变动
                stock_record = StockRecord(
                    product_id=product.id,
                    change_type='退货',
                    change_quantity=refund_qty,
                    before_quantity=before_quantity,
                    after_quantity=product.stock_quantity,
                    reference_type='refund',
                    reference_id=sale.id,
                    notes=f'退货单：{sale.order_no}',
                    operator_id=current_user.id
                )
                db.session.add(stock_record)
        
        sale.order_status = '已退货'
        sale.payment_status = '已退款'
        
        # 退还会员积分
        if sale.customer:
            sale.customer.total_consumption -= sale.actual_amount
            sale.customer.points -= sale.points_earned
            sale.customer.points += sale.points_used
        
        db.session.commit()
        
        log_action('退货退款', '销售管理', f'退货单：{sale.order_no}')
        flash('退货成功', 'success')
        return redirect(url_for('view_sale', id=id))
    
    return render_template('sales/refund.html', sale=sale)


# ==================== 库存管理路由 ====================

@app.route('/inventory')
@login_required
def inventory():
    """库存查询"""
    page = request.args.get('page', 1, type=int)
    search = request.args.get('search', '')
    category_id = request.args.get('category_id', type=int)
    stock_status = request.args.get('stock_status', '')
    
    query = Product.query.filter_by(is_active=True)
    
    if search:
        query = query.filter(
            (Product.name.contains(search)) |
            (Product.code.contains(search))
        )
    
    if category_id:
        query = query.filter_by(category_id=category_id)
    
    if stock_status == 'low':
        query = query.filter(Product.stock_quantity <= Product.min_stock)
    elif stock_status == 'out':
        query = query.filter(Product.stock_quantity == 0)
    elif stock_status == 'over':
        query = query.filter(Product.stock_quantity > Product.max_stock)
    
    pagination = query.order_by(Product.stock_quantity.asc()).paginate(
        page=page, per_page=20, error_out=False
    )
    
    categories = Category.query.all()
    
    # 库存统计
    total_value = db.session.query(
        db.func.sum(Product.stock_quantity * Product.purchase_price)
    ).filter(Product.is_active == True).scalar() or 0
    
    low_stock_count = Product.query.filter(
        Product.stock_quantity <= Product.min_stock,
        Product.is_active == True
    ).count()
    
    out_stock_count = Product.query.filter(
        Product.stock_quantity == 0,
        Product.is_active == True
    ).count()
    
    return render_template('inventory/list.html',
        products=pagination.items,
        pagination=pagination,
        categories=categories,
        search=search,
        category_id=category_id,
        stock_status=stock_status,
        total_value=total_value,
        low_stock_count=low_stock_count,
        out_stock_count=out_stock_count
    )


@app.route('/inventory/adjust/<int:id>', methods=['GET', 'POST'])
@login_required
@manager_required
def adjust_stock(id):
    """库存调整"""
    product = Product.query.get_or_404(id)
    
    if request.method == 'POST':
        change_type = request.form.get('change_type')
        quantity = request.form.get('quantity', type=int)
        notes = request.form.get('notes')
        
        if quantity and quantity != 0:
            before_quantity = product.stock_quantity
            
            if change_type == '入库':
                product.stock_quantity += quantity
                change_quantity = quantity
            elif change_type == '出库':
                product.stock_quantity -= quantity
                change_quantity = -quantity
            elif change_type == '盘点':
                change_quantity = quantity - before_quantity
                product.stock_quantity = quantity
            elif change_type == '损耗':
                product.stock_quantity -= quantity
                change_quantity = -quantity
            
            # 记录库存变动
            stock_record = StockRecord(
                product_id=product.id,
                change_type=change_type,
                change_quantity=change_quantity,
                before_quantity=before_quantity,
                after_quantity=product.stock_quantity,
                reference_type='adjust',
                notes=notes,
                operator_id=current_user.id
            )
            db.session.add(stock_record)
            db.session.commit()
            
            log_action('库存调整', '库存管理', f'{product.name} {change_type} {quantity}')
            flash('库存调整成功', 'success')
            return redirect(url_for('inventory'))
    
    return render_template('inventory/adjust.html', product=product)


@app.route('/inventory/records')
@login_required
def stock_records():
    """库存变动记录"""
    page = request.args.get('page', 1, type=int)
    product_id = request.args.get('product_id', type=int)
    change_type = request.args.get('change_type', '')
    
    query = StockRecord.query
    
    if product_id:
        query = query.filter_by(product_id=product_id)
    
    if change_type:
        query = query.filter_by(change_type=change_type)
    
    pagination = query.order_by(StockRecord.created_at.desc()).paginate(
        page=page, per_page=50, error_out=False
    )
    
    products = Product.query.filter_by(is_active=True).all()
    
    return render_template('inventory/records.html',
        records=pagination.items,
        pagination=pagination,
        products=products,
        product_id=product_id,
        change_type=change_type
    )


@app.route('/inventory/checks')
@login_required
def inventory_checks():
    """盘点记录列表"""
    page = request.args.get('page', 1, type=int)
    status = request.args.get('status', '')
    
    query = InventoryCheck.query
    
    if status:
        query = query.filter_by(status=status)
    
    pagination = query.order_by(InventoryCheck.created_at.desc()).paginate(
        page=page, per_page=20, error_out=False
    )
    
    return render_template('inventory/checks.html',
        checks=pagination.items,
        pagination=pagination,
        status=status
    )


@app.route('/inventory/checks/new', methods=['GET', 'POST'])
@login_required
@manager_required
def new_inventory_check():
    """新建盘点"""
    if request.method == 'POST':
        category_id = request.form.get('category_id', type=int)
        notes = request.form.get('notes')
        
        # 获取要盘点的商品
        query = Product.query.filter_by(is_active=True)
        if category_id:
            query = query.filter_by(category_id=category_id)
        
        products = query.all()
        
        check = InventoryCheck(
            check_no=InventoryCheck.generate_check_no(),
            total_products=len(products),
            notes=notes,
            operator_id=current_user.id
        )
        db.session.add(check)
        
        for product in products:
            item = InventoryCheckItem(
                check=check,
                product_id=product.id,
                system_quantity=product.stock_quantity
            )
            db.session.add(item)
        
        db.session.commit()
        
        log_action('新建盘点', '库存管理', f'盘点单：{check.check_no}')
        flash('盘点单创建成功，请开始盘点', 'success')
        return redirect(url_for('do_inventory_check', id=check.id))
    
    categories = Category.query.all()
    return render_template('inventory/check_form.html', categories=categories)


@app.route('/inventory/checks/<int:id>')
@login_required
def do_inventory_check(id):
    """执行盘点"""
    check = InventoryCheck.query.get_or_404(id)
    return render_template('inventory/check_do.html', check=check)


@app.route('/inventory/checks/<int:id>/save', methods=['POST'])
@login_required
def save_inventory_check(id):
    """保存盘点结果"""
    check = InventoryCheck.query.get_or_404(id)
    
    actual_quantities = request.form.getlist('actual_quantity[]')
    item_notes = request.form.getlist('notes[]')
    
    checked_count = 0
    difference_count = 0
    
    for i, item in enumerate(check.items):
        if actual_quantities[i]:
            actual_qty = int(actual_quantities[i])
            item.actual_quantity = actual_qty
            item.difference = actual_qty - item.system_quantity
            item.notes = item_notes[i] if item_notes[i] else None
            checked_count += 1
            
            if item.difference != 0:
                difference_count += 1
    
    check.checked_products = checked_count
    check.difference_count = difference_count
    db.session.commit()
    
    flash('盘点数据已保存', 'success')
    return redirect(url_for('do_inventory_check', id=id))


@app.route('/inventory/checks/<int:id>/complete', methods=['POST'])
@login_required
@manager_required
def complete_inventory_check(id):
    """完成盘点并调整库存"""
    check = InventoryCheck.query.get_or_404(id)
    
    for item in check.items:
        if item.actual_quantity is not None and item.difference != 0:
            product = item.product
            before_quantity = product.stock_quantity
            product.stock_quantity = item.actual_quantity
            
            # 记录库存变动
            stock_record = StockRecord(
                product_id=product.id,
                change_type='盘点',
                change_quantity=item.difference,
                before_quantity=before_quantity,
                after_quantity=item.actual_quantity,
                reference_type='inventory',
                reference_id=check.id,
                notes=f'盘点单：{check.check_no}',
                operator_id=current_user.id
            )
            db.session.add(stock_record)
    
    check.status = '已完成'
    check.completed_at = datetime.utcnow()
    db.session.commit()
    
    log_action('完成盘点', '库存管理', f'盘点单：{check.check_no}')
    flash('盘点完成，库存已调整', 'success')
    return redirect(url_for('inventory_checks'))


# ==================== 报表路由 ====================

@app.route('/reports')
@login_required
def reports():
    """报表中心"""
    return render_template('reports/index.html')


@app.route('/reports/sales')
@login_required
@manager_required
def sales_report():
    """销售报表"""
    date_from = request.args.get('date_from', '')
    date_to = request.args.get('date_to', '')
    
    if not date_from:
        date_from = (datetime.utcnow() - timedelta(days=30)).strftime('%Y-%m-%d')
    if not date_to:
        date_to = datetime.utcnow().strftime('%Y-%m-%d')
    
    start_date = datetime.strptime(date_from, '%Y-%m-%d')
    end_date = datetime.strptime(date_to, '%Y-%m-%d') + timedelta(days=1)
    
    # 销售统计
    sales_stats = db.session.query(
        db.func.count(Sale.id).label('order_count'),
        db.func.sum(Sale.total_amount).label('total_amount'),
        db.func.sum(Sale.actual_amount).label('actual_amount'),
        db.func.sum(Sale.discount_amount).label('discount_amount')
    ).filter(
        Sale.created_at.between(start_date, end_date),
        Sale.order_status == '已完成'
    ).first()
    
    sales_summary = {
        'order_count': int(sales_stats[0]) if sales_stats[0] else 0,
        'total_amount': float(sales_stats[1]) if sales_stats[1] else 0,
        'actual_amount': float(sales_stats[2]) if sales_stats[2] else 0,
        'discount_amount': float(sales_stats[3]) if sales_stats[3] else 0
    }
    
    # 每日销售趋势
    daily_sales_raw = db.session.query(
        db.func.date(Sale.created_at).label('date'),
        db.func.count(Sale.id).label('order_count'),
        db.func.sum(Sale.actual_amount).label('amount')
    ).filter(
        Sale.created_at.between(start_date, end_date),
        Sale.order_status == '已完成'
    ).group_by(db.func.date(Sale.created_at)).all()
    
    daily_sales = []
    for row in daily_sales_raw:
        daily_sales.append({
            'date': str(row[0]) if row[0] else '',
            'order_count': int(row[1]) if row[1] else 0,
            'amount': float(row[2]) if row[2] else 0
        })
    
    # 支付方式统计
    payment_stats_raw = db.session.query(
        Sale.payment_method,
        db.func.count(Sale.id).label('count'),
        db.func.sum(Sale.actual_amount).label('amount')
    ).filter(
        Sale.created_at.between(start_date, end_date),
        Sale.order_status == '已完成'
    ).group_by(Sale.payment_method).all()
    
    payment_stats = []
    for row in payment_stats_raw:
        payment_stats.append({
            'payment_method': row[0] if row[0] else '',
            'count': int(row[1]) if row[1] else 0,
            'amount': float(row[2]) if row[2] else 0
        })
    
    hot_products = db.session.query(
        Product,
        db.func.sum(SaleItem.quantity).label('sold_qty'),
        db.func.sum(SaleItem.subtotal).label('amount')
    ).join(SaleItem).join(Sale).filter(
        Sale.created_at.between(start_date, end_date),
        Sale.order_status == '已完成'
    ).group_by(Product.id).order_by(db.func.sum(SaleItem.quantity).desc()).limit(20).all()
    
    staff_sales = db.session.query(
        User,
        db.func.count(Sale.id).label('order_count'),
        db.func.sum(Sale.actual_amount).label('amount')
    ).join(Sale, User.id == Sale.user_id).filter(
        Sale.created_at.between(start_date, end_date),
        Sale.order_status == '已完成'
    ).group_by(User.id).order_by(db.func.sum(Sale.actual_amount).desc()).limit(10).all()
    
    return render_template('reports/sales.html',
        date_from=date_from,
        date_to=date_to,
        sales_summary=sales_summary,
        daily_sales=daily_sales,
        payment_stats=payment_stats,
        hot_products=hot_products,
        staff_sales=staff_sales
    )


@app.route('/reports/profit')
@login_required
@manager_required
def profit_report():
    """利润报表"""
    date_from = request.args.get('date_from', '')
    date_to = request.args.get('date_to', '')
    
    if not date_from:
        date_from = (datetime.utcnow() - timedelta(days=30)).strftime('%Y-%m-%d')
    if not date_to:
        date_to = datetime.utcnow().strftime('%Y-%m-%d')
    
    start_date = datetime.strptime(date_from, '%Y-%m-%d')
    end_date = datetime.strptime(date_to, '%Y-%m-%d') + timedelta(days=1)
    
    daily_profit_raw = db.session.query(
        db.func.date(Sale.created_at).label('date'),
        db.func.sum(SaleItem.subtotal).label('revenue'),
        db.func.sum(SaleItem.quantity * Product.purchase_price).label('cost')
    ).join(SaleItem, Sale.id == SaleItem.sale_id).join(Product, SaleItem.product_id == Product.id).filter(
        Sale.created_at.between(start_date, end_date),
        Sale.order_status == '已完成'
    ).group_by(db.func.date(Sale.created_at)).order_by(db.func.date(Sale.created_at)).all()
    
    profit_data = []
    for row in daily_profit_raw:
        revenue = float(row[1]) if row[1] else 0
        cost = float(row[2]) if row[2] else 0
        profit_data.append({
            'date': str(row[0]) if row[0] else '',
            'revenue': revenue,
            'cost': cost,
            'profit': revenue - cost
        })
    
    product_profit_raw = db.session.query(
        Product,
        db.func.sum(SaleItem.quantity).label('sold_qty'),
        db.func.sum(SaleItem.subtotal).label('revenue'),
        db.func.sum(SaleItem.quantity * Product.purchase_price).label('cost')
    ).join(SaleItem).join(Sale).filter(
        Sale.created_at.between(start_date, end_date),
        Sale.order_status == '已完成'
    ).group_by(Product.id).order_by(
        (db.func.sum(SaleItem.subtotal) - db.func.sum(SaleItem.quantity * Product.purchase_price)).desc()
    ).limit(20).all()
    
    product_profit = []
    for row in product_profit_raw:
        product = row[0]
        qty = int(row[1]) if row[1] else 0
        revenue = float(row[2]) if row[2] else 0
        cost = float(row[3]) if row[3] else 0
        profit = revenue - cost
        product_profit.append((product, qty, revenue, cost, profit))
    
    # 计算总计
    total_revenue = sum(item['revenue'] for item in profit_data)
    total_cost = sum(item['cost'] for item in profit_data)
    total_profit = total_revenue - total_cost
    profit_margin = (total_profit / total_revenue * 100) if total_revenue > 0 else 0
    
    return render_template('reports/profit.html',
        date_from=date_from,
        date_to=date_to,
        profit_data=profit_data,
        product_profit=product_profit,
        total_revenue=total_revenue,
        total_cost=total_cost,
        total_profit=total_profit,
        profit_margin=profit_margin
    )


@app.route('/reports/inventory')
@login_required
def inventory_report():
    """库存报表"""
    inventory_stats = db.session.query(
        db.func.count(Product.id).label('product_count'),
        db.func.sum(Product.stock_quantity).label('total_quantity'),
        db.func.sum(Product.stock_quantity * Product.purchase_price).label('cost_value'),
        db.func.sum(Product.stock_quantity * Product.selling_price).label('retail_value')
    ).filter(Product.is_active == True).first()
    
    inventory_value = {
        'product_count': int(inventory_stats[0]) if inventory_stats[0] else 0,
        'total_quantity': int(inventory_stats[1]) if inventory_stats[1] else 0,
        'purchase_value': float(inventory_stats[2]) if inventory_stats[2] else 0,
        'selling_value': float(inventory_stats[3]) if inventory_stats[3] else 0
    }
    
    category_stats_raw = db.session.query(
        Category.name,
        db.func.count(Product.id).label('product_count'),
        db.func.sum(Product.stock_quantity).label('total_quantity'),
        db.func.sum(Product.stock_quantity * Product.purchase_price).label('cost_value')
    ).join(Product).filter(Product.is_active == True).group_by(Category.id).all()
    
    category_stats = []
    for row in category_stats_raw:
        category_stats.append((
            row[0] if row[0] else '未分类',
            int(row[1]) if row[1] else 0,
            int(row[2]) if row[2] else 0,
            float(row[3]) if row[3] else 0
        ))
    
    low_stock = Product.query.filter(
        Product.stock_quantity <= Product.min_stock,
        Product.is_active == True
    ).all()
    
    thirty_days_ago = datetime.utcnow() - timedelta(days=30)
    
    # 获取30天内有销售的商品ID
    sold_product_ids = db.session.query(SaleItem.product_id).join(Sale).filter(
        Sale.created_at >= thirty_days_ago,
        Sale.order_status == '已完成'
    ).distinct().subquery()
    
    # 滞销商品：30天内无销售且有库存的商品
    slow_moving = Product.query.filter(
        Product.is_active == True,
        Product.stock_quantity > 0,
        ~Product.id.in_(db.session.query(sold_product_ids))
    ).limit(20).all()
    
    return render_template('reports/inventory.html',
        inventory_value=inventory_value,
        category_stats=category_stats,
        low_stock=low_stock,
        slow_moving=slow_moving
    )


@app.route('/reports/purchase')
@login_required
def purchase_report():
    """进货报表"""
    date_from = request.args.get('date_from', '')
    date_to = request.args.get('date_to', '')
    
    if not date_from:
        date_from = (datetime.utcnow() - timedelta(days=30)).strftime('%Y-%m-%d')
    if not date_to:
        date_to = datetime.utcnow().strftime('%Y-%m-%d')
    
    start_date = datetime.strptime(date_from, '%Y-%m-%d')
    end_date = datetime.strptime(date_to, '%Y-%m-%d') + timedelta(days=1)
    
    purchase_stats = db.session.query(
        db.func.count(Purchase.id).label('order_count'),
        db.func.sum(Purchase.total_amount).label('total_amount'),
        db.func.sum(Purchase.paid_amount).label('paid_amount')
    ).filter(
        Purchase.created_at.between(start_date, end_date)
    ).first()
    
    purchase_summary = {
        'order_count': int(purchase_stats[0]) if purchase_stats[0] else 0,
        'total_amount': float(purchase_stats[1]) if purchase_stats[1] else 0,
        'paid_amount': float(purchase_stats[2]) if purchase_stats[2] else 0
    }
    
    supplier_stats_raw = db.session.query(
        Supplier.name,
        db.func.count(Purchase.id).label('order_count'),
        db.func.sum(Purchase.total_amount).label('total_amount')
    ).join(Purchase).filter(
        Purchase.created_at.between(start_date, end_date)
    ).group_by(Supplier.id).all()
    
    supplier_stats = []
    for row in supplier_stats_raw:
        supplier_stats.append((
            row[0] if row[0] else '未指定',
            int(row[1]) if row[1] else 0,
            float(row[2]) if row[2] else 0
        ))
    
    purchase_details_raw = db.session.query(
        Product.name,
        db.func.sum(PurchaseItem.quantity).label('total_qty'),
        db.func.sum(PurchaseItem.subtotal).label('total_amount')
    ).join(PurchaseItem).join(Purchase).filter(
        Purchase.created_at.between(start_date, end_date)
    ).group_by(Product.id).order_by(db.func.sum(PurchaseItem.subtotal).desc()).limit(20).all()
    
    purchase_details = []
    for row in purchase_details_raw:
        purchase_details.append((
            row[0] if row[0] else '',
            int(row[1]) if row[1] else 0,
            float(row[2]) if row[2] else 0
        ))
    
    return render_template('reports/purchase.html',
        date_from=date_from,
        date_to=date_to,
        purchase_summary=purchase_summary,
        supplier_stats=supplier_stats,
        purchase_details=purchase_details
    )


# ==================== 用户管理路由 ====================

@app.route('/users')
@login_required
@admin_required
def users():
    """用户列表"""
    page = request.args.get('page', 1, type=int)
    search = request.args.get('search', '')
    role = request.args.get('role', '')
    status = request.args.get('status', '')
    
    query = User.query
    
    if search:
        query = query.filter(
            (User.username.contains(search)) |
            (User.email.contains(search)) |
            (User.phone.contains(search))
        )
    
    if role:
        query = query.filter_by(role=role)
    
    if status == 'active':
        query = query.filter_by(is_active=True)
    elif status == 'inactive':
        query = query.filter_by(is_active=False)
    
    pagination = query.order_by(User.created_at.desc()).paginate(
        page=page, per_page=20, error_out=False
    )
    
    # 获取所有可用角色
    available_roles = get_all_roles()
    
    return render_template('users/list.html',
        users=pagination.items,
        pagination=pagination,
        search=search,
        role=role,
        status=status,
        available_roles=available_roles
    )


@app.route('/users/add', methods=['GET', 'POST'])
@login_required
@admin_required
def add_user():
    """添加用户"""
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')
        
        if password != confirm_password:
            flash('两次输入的密码不一致', 'error')
            return render_template('users/form.html', available_roles=get_all_roles())
        
        if User.query.filter_by(username=username).first():
            flash('用户名已存在', 'error')
            return render_template('users/form.html', available_roles=get_all_roles())
        
        if User.query.filter_by(email=email).first():
            flash('邮箱已被注册', 'error')
            return render_template('users/form.html', available_roles=get_all_roles())
        
        user = User(
            username=username,
            email=email,
            phone=request.form.get('phone'),
            role=request.form.get('role', 'staff')
        )
        user.set_password(password)
        
        db.session.add(user)
        db.session.commit()
        
        log_action('添加用户', '用户管理', f'添加用户：{username}')
        flash('用户添加成功', 'success')
        return redirect(url_for('users'))
    
    return render_template('users/form.html', available_roles=get_all_roles())


@app.route('/users/edit/<int:id>', methods=['GET', 'POST'])
@login_required
@admin_required
def edit_user(id):
    """编辑用户"""
    user = User.query.get_or_404(id)
    
    if request.method == 'POST':
        user.email = request.form.get('email')
        user.phone = request.form.get('phone')
        user.role = request.form.get('role', 'staff')
        
        password = request.form.get('password')
        if password:
            confirm_password = request.form.get('confirm_password')
            if password != confirm_password:
                flash('两次输入的密码不一致', 'error')
                return render_template('users/form.html', user=user, available_roles=get_all_roles())
            user.set_password(password)
        
        db.session.commit()
        
        log_action('编辑用户', '用户管理', f'编辑用户：{user.username}')
        flash('用户更新成功', 'success')
        return redirect(url_for('users'))
    
    return render_template('users/form.html', user=user, available_roles=get_all_roles())


@app.route('/users/toggle/<int:id>', methods=['POST'])
@login_required
@admin_required
def toggle_user(id):
    """启用/禁用用户"""
    user = User.query.get_or_404(id)
    
    if user.id == current_user.id:
        flash('不能禁用自己', 'error')
        return redirect(url_for('users'))
    
    user.is_active = not user.is_active
    db.session.commit()
    
    status = '启用' if user.is_active else '禁用'
    log_action(f'{status}用户', '用户管理', f'{status}用户：{user.username}')
    flash(f'用户已{status}', 'success')
    return redirect(url_for('users'))


@app.route('/profile', methods=['GET', 'POST'])
@login_required
def profile():
    """个人资料"""
    if request.method == 'POST':
        current_user.phone = request.form.get('phone')
        
        old_password = request.form.get('old_password')
        new_password = request.form.get('new_password')
        
        if old_password and new_password:
            if current_user.check_password(old_password):
                current_user.set_password(new_password)
                flash('密码修改成功', 'success')
            else:
                flash('原密码错误', 'error')
                return render_template('users/profile.html')
        
        db.session.commit()
        flash('个人资料已更新', 'success')
    
    return render_template('users/profile.html')


# ==================== 系统设置路由 ====================

@app.route('/settings')
@login_required
@admin_required
def settings():
    """系统设置"""
    settings = {}
    for setting in SystemSetting.query.all():
        settings[setting.key] = setting.value
    
    return render_template('settings/index.html', settings=settings)


@app.route('/settings/save', methods=['POST'])
@login_required
@admin_required
def save_settings():
    """保存系统设置"""
    settings_to_save = [
        'shop_name', 'shop_address', 'shop_phone',
        'receipt_footer', 'points_rate', 'low_stock_alert'
    ]
    
    for key in settings_to_save:
        value = request.form.get(key, '')
        set_setting(key, value)
    
    log_action('保存设置', '系统设置', '更新系统设置')
    flash('设置已保存', 'success')
    return redirect(url_for('settings'))


@app.route('/settings/logs')
@login_required
@admin_required
def system_logs():
    """系统日志"""
    page = request.args.get('page', 1, type=int)
    module = request.args.get('module', '')
    date_from = request.args.get('date_from', '')
    date_to = request.args.get('date_to', '')
    
    query = SystemLog.query
    
    if module:
        query = query.filter_by(module=module)
    
    if date_from:
        query = query.filter(SystemLog.created_at >= datetime.strptime(date_from, '%Y-%m-%d'))
    
    if date_to:
        query = query.filter(SystemLog.created_at <= datetime.strptime(date_to, '%Y-%m-%d') + timedelta(days=1))
    
    pagination = query.order_by(SystemLog.created_at.desc()).paginate(
        page=page, per_page=50, error_out=False
    )
    
    # 获取所有模块
    modules = db.session.query(SystemLog.module).distinct().all()
    modules = [m[0] for m in modules if m[0]]
    
    return render_template('settings/logs.html',
        logs=pagination.items,
        pagination=pagination,
        modules=modules,
        module=module,
        date_from=date_from,
        date_to=date_to
    )


@app.route('/settings/backup')
@login_required
@admin_required
def backup_database():
    """备份数据库"""
    import shutil
    
    # 确保备份目录存在
    backup_dir = os.path.join(os.path.dirname(__file__), 'backups')
    if not os.path.exists(backup_dir):
        os.makedirs(backup_dir)
    
    # 创建备份文件
    db_path = os.path.join(os.path.dirname(__file__), 'instance', 'shop.db')
    backup_filename = f"backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.db"
    backup_path = os.path.join(backup_dir, backup_filename)
    
    try:
        shutil.copy2(db_path, backup_path)
        log_action('备份数据库', '系统设置', f'创建备份：{backup_filename}')
        flash(f'备份成功：{backup_filename}', 'success')
    except Exception as e:
        flash(f'备份失败：{str(e)}', 'error')
    
    return redirect(url_for('settings'))


# ==================== API 路由 ====================

@app.route('/api/products/search')
@login_required
def api_search_products():
    """搜索商品API"""
    q = request.args.get('q', '')
    category_id = request.args.get('category_id', type=int)
    
    query = Product.query.filter_by(is_active=True)
    
    if q:
        query = query.filter(
            (Product.name.contains(q)) |
            (Product.code.contains(q))
        )
    
    if category_id:
        query = query.filter_by(category_id=category_id)
    
    products = query.limit(20).all()
    
    return jsonify([{
        'id': p.id,
        'code': p.code,
        'name': p.name,
        'unit': p.unit,
        'selling_price': p.selling_price,
        'wholesale_price': p.wholesale_price,
        'member_price': p.member_price,
        'stock_quantity': p.stock_quantity,
        'category': p.category.name if p.category else ''
    } for p in products])


@app.route('/api/customers/search')
@login_required
def api_search_customers():
    """搜索客户API"""
    q = request.args.get('q', '')
    
    query = Customer.query.filter_by(is_active=True)
    
    if q:
        query = query.filter(
            (Customer.name.contains(q)) |
            (Customer.phone.contains(q))
        )
    
    customers = query.limit(10).all()
    
    return jsonify([{
        'id': c.id,
        'name': c.name,
        'phone': c.phone,
        'member_level': c.member_level,
        'points': c.points,
        'balance': c.balance
    } for c in customers])


@app.route('/api/dashboard/stats')
@login_required
def api_dashboard_stats():
    """仪表盘统计API"""
    today = datetime.utcnow().date()
    today_start = datetime.combine(today, datetime.min.time())
    today_end = datetime.combine(today, datetime.max.time())
    
    # 今日销售额
    today_sales = db.session.query(db.func.sum(Sale.actual_amount)).filter(
        Sale.created_at.between(today_start, today_end),
        Sale.order_status == '已完成'
    ).scalar() or 0
    
    # 今日订单数
    today_orders = Sale.query.filter(
        Sale.created_at.between(today_start, today_end)
    ).count()
    
    # 库存预警
    low_stock_count = Product.query.filter(
        Product.stock_quantity <= Product.min_stock,
        Product.is_active == True
    ).count()
    
    return jsonify({
        'today_sales': float(today_sales),
        'today_orders': today_orders,
        'low_stock_count': low_stock_count
    })


# ==================== 错误处理 ====================

@app.errorhandler(404)
def page_not_found(e):
    return render_template('errors/404.html'), 404


@app.errorhandler(500)
def internal_server_error(e):
    return render_template('errors/500.html'), 500


@app.errorhandler(403)
def forbidden(e):
    return render_template('errors/403.html'), 403


# ==================== 初始化数据库 ====================

def init_db():
    """初始化数据库"""
    with app.app_context():
        db.create_all()
        
        # 初始化系统设置
        default_settings = [
            ('shop_name', '小型店铺管理系统', '店铺名称'),
            ('shop_address', '', '店铺地址'),
            ('shop_phone', '', '联系电话'),
            ('receipt_footer', '感谢您的光临！', '小票底部信息'),
            ('points_rate', '1', '积分比例（消费1元=N积分）'),
            ('low_stock_alert', '10', '库存预警阈值'),
        ]
        
        for key, value, desc in default_settings:
            if not SystemSetting.query.filter_by(key=key).first():
                setting = SystemSetting(key=key, value=value, description=desc)
                db.session.add(setting)
        
        # 初始化默认分类
        default_categories = ['食品饮料', '日用百货', '生鲜果蔬', '烟酒茶', '零食糖果', '其他']
        for name in default_categories:
            if not Category.query.filter_by(name=name).first():
                category = Category(name=name)
                db.session.add(category)
        
        default_units = ['个', '件', '箱', '瓶', '袋', '包', '斤', '千克', '克', '升', '毫升', '米', '厘米', '套', '台', '只', '双', '把', '盒', '罐']
        for name in default_units:
            if not Unit.query.filter_by(name=name).first():
                unit = Unit(name=name)
                db.session.add(unit)
        
        default_member_levels = [
            ('普通', 1.0, 1.0, 0, '普通会员'),
            ('银卡', 0.98, 1.2, 1000, '累计消费满1000元'),
            ('金卡', 0.95, 1.5, 5000, '累计消费满5000元'),
            ('钻石', 0.90, 2.0, 20000, '累计消费满20000元'),
        ]
        for name, discount, points_multiplier, min_consumption, description in default_member_levels:
            if not MemberLevel.query.filter_by(name=name).first():
                level = MemberLevel(
                    name=name,
                    discount=discount,
                    points_multiplier=points_multiplier,
                    min_consumption=min_consumption,
                    description=description
                )
                db.session.add(level)
        
        default_payment_methods = [
            ('现金', 'bi-cash', '现金支付', 1),
            ('微信', 'bi-wechat', '微信支付', 2),
            ('支付宝', 'bi-alipay', '支付宝支付', 3),
            ('银行卡', 'bi-credit-card', '银行卡支付', 4),
            ('会员余额', 'bi-wallet', '会员账户余额支付', 5),
        ]
        for name, icon, description, sort_order in default_payment_methods:
            if not PaymentMethod.query.filter_by(name=name).first():
                method = PaymentMethod(
                    name=name,
                    icon=icon,
                    description=description,
                    sort_order=sort_order
                )
                db.session.add(method)
        
        default_roles = [
            ('admin', '管理员', '系统管理员，拥有所有权限'),
            ('manager', '经理', '店铺经理，拥有管理权限'),
            ('staff', '员工', '普通员工'),
            ('cashier', '收银员', '收银员，负责收银操作'),
            ('warehouse', '仓库管理员', '仓库管理员，负责进货和库存'),
            ('customer', '客户', '客户账号'),
        ]
        for code, name, description in default_roles:
            if not Role.query.filter_by(code=code).first():
                role = Role(code=code, name=name, description=description)
                db.session.add(role)
        
        db.session.commit()
        print('数据库初始化完成！')


# ==================== 主入口 ====================

if __name__ == '__main__':
    init_db()
    app.run(debug=True, host='0.0.0.0', port=5000)
