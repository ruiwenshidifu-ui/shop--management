#!/bin/bash

echo "========================================"
echo "   Shop Management System - Launcher"
echo "========================================"
echo

# Color definitions
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

# Check if Python is installed
echo -e "[1/5] Checking Python environment..."
if command -v python3 &> /dev/null; then
    PYTHON_CMD="python3"
elif command -v python &> /dev/null; then
    PYTHON_CMD="python"
else
    echo -e "${RED}[ERROR] Python not found!${NC}"
    echo "Please install Python 3.8+"
    echo "Ubuntu/Debian: sudo apt install python3 python3-pip python3-venv"
    echo "CentOS/RHEL: sudo yum install python3 python3-pip"
    echo "macOS: brew install python3"
    exit 1
fi
echo -e "${GREEN}[OK] Python is installed${NC}"
$PYTHON_CMD --version

# Create virtual environment if not exists
echo
echo -e "[2/5] Setting up virtual environment..."
if [ ! -d "venv" ]; then
    echo "Creating virtual environment..."
    $PYTHON_CMD -m venv venv
    if [ $? -ne 0 ]; then
        echo -e "${RED}[ERROR] Failed to create virtual environment${NC}"
        echo "Try: sudo apt install python3-venv (on Ubuntu/Debian)"
        exit 1
    fi
    echo "Virtual environment created successfully"
else
    echo "Virtual environment already exists"
fi
echo -e "${GREEN}[OK] Virtual environment ready${NC}"

# Activate virtual environment
echo
echo -e "[3/5] Activating virtual environment..."
source venv/bin/activate
if [ $? -ne 0 ]; then
    echo -e "${RED}[ERROR] Failed to activate virtual environment${NC}"
    exit 1
fi
echo -e "${GREEN}[OK] Virtual environment activated${NC}"

# Install dependencies
echo
echo -e "[4/5] Installing dependencies..."
echo "This may take a few minutes on first run..."
pip install --upgrade pip -q 2>/dev/null
pip install -r requirements.txt -q 2>/dev/null
if [ $? -ne 0 ]; then
    echo -e "${YELLOW}[WARNING] Some dependencies may have failed${NC}"
    echo "Installing core dependencies..."
    pip install flask flask-sqlalchemy flask-login werkzeug
fi
echo -e "${GREEN}[OK] Dependencies installed${NC}"

# Start application
echo
echo -e "[5/5] Starting application..."
echo "========================================"
echo
echo "   System is starting..."
echo
echo -e "   ${YELLOW}Access URL: http://127.0.0.1:5000${NC}"
echo
echo "   Press Ctrl+C to stop the server"
echo
echo "========================================"
echo

# Open browser automatically (works on most systems)
sleep 2 && (
    if command -v xdg-open &> /dev/null; then
        xdg-open http://127.0.0.1:5000
    elif command -v open &> /dev/null; then
        open http://127.0.0.1:5000
    fi
) &

# Run the application
$PYTHON_CMD app.py
